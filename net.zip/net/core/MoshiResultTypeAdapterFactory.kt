package com.iflytek.easytrans.crossdevice.translation.net.core

import com.iflytek.easytrans.crossdevice.translation.net.error.BusinessException
import com.squareup.moshi.*
import java.lang.reflect.ParameterizedType
import java.lang.reflect.Type

/**
 *
 *   {
 *     "data": {
 *      }
 *     "errorCode": 0,
 *     "errorMsg": ""
 *   }
 * @author jjxie9
 * @date 2024/9/23
 * @description  取出data泛型数据(减少数据嵌套,精简代码)
 *
 */
class MoshiResultTypeAdapterFactory(private val httpWrapper: HttpWrapper?) : JsonAdapter.Factory {

    interface HttpWrapper {
        fun getStatusCodeKey(): String
        fun getErrorMsgKey(): String
        fun getDataKey(): String

        //有些服务器是0代表成功,有些是000000成功,根据情况修改
        //这里的成功是指业务请求的成功
        fun isRequestSuccess(statusCode: Int?): Boolean
    }

    override fun create(
        type: Type,
        annotations: MutableSet<out Annotation>,
        moshi: Moshi
    ): JsonAdapter<*>? {
        val rawType = type.rawType
        if (rawType != HttpResult::class.java) return null
        val dataType: Type =
            (type as? ParameterizedType)?.actualTypeArguments?.firstOrNull() ?: return null
        val dataTypeAdapter =
            moshi.nextAdapter<Any>(this, dataType, annotations)
        //Result<T> 范型解析出来
        return ResultTypeAdapter(dataTypeAdapter, httpWrapper)
    }

    /**
     * 返回请求需要的那个T
     *
     */
    class ResultTypeAdapter<T>(
        private val dataTypeAdapter: JsonAdapter<T>,
        private val httpWrapper: HttpWrapper?
    ) : JsonAdapter<T>() {
        override fun fromJson(reader: JsonReader): T? {
            if (httpWrapper != null) {
                reader.beginObject()
                //一般都是code +msg + result/data
                var errcode: Int? = null
                var msg: String? = null
                var data: Any? = null
                while (reader.hasNext()) {
                    when (reader.nextName()) {
                        //根据不同服务器后台HTTP 报文字段 解析映射出code + msg + data
                        httpWrapper.getStatusCodeKey() -> errcode =
                            reader.nextString().toIntOrNull()
                        httpWrapper.getErrorMsgKey() -> msg = reader.nextString()
                        httpWrapper.getDataKey() -> data = dataTypeAdapter.fromJson(reader)
                        else -> reader.skipValue()
                    }
                }
                reader.endObject()
                // 这个字段要看看是否服务器是否是必传字段
                // 否则没有必要抛异常
                if (httpWrapper.isRequestSuccess(errcode)) {
                    return data as T
                } else {
                    throw BusinessException(errcode ?: -1, msg)
                }
            } else {
                return dataTypeAdapter.fromJson(reader) as T
            }
        }

        override fun toJson(writer: JsonWriter, value: T?) {
            if (value != null && httpWrapper != null) {
                writer.beginObject()
                writeField(writer, value, httpWrapper.getStatusCodeKey())
                writeField(writer, value, httpWrapper.getErrorMsgKey())
                writer.name(httpWrapper.getDataKey())
                dataTypeAdapter.toJson(writer, value)
                writer.endObject()
            } else {
                dataTypeAdapter.toJson(writer, value)
            }
        }

        private fun writeField(writer: JsonWriter, value: T, fieldName: String) {
            val field =
                value!!::class.java.getDeclaredField(fieldName).apply { isAccessible = true }
            writer.name(fieldName).value(field.get(value)?.toString())
        }
    }
}


