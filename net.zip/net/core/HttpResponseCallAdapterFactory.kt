package com.iflytek.easytrans.crossdevice.translation.net.core

import com.iflytek.easytrans.crossdevice.translation.net.error.BusinessException
import retrofit2.Call
import retrofit2.CallAdapter
import retrofit2.Retrofit
import java.lang.reflect.ParameterizedType
import java.lang.reflect.Type

class HttpResponseCallAdapterFactory(private val errorHandler: ErrorHandler? = null) :
    CallAdapter.Factory() {


    fun interface ErrorHandler {
        fun onFailure(throwable: BusinessException)
    }

    override fun get(
        returnType: Type,
        annotations: Array<Annotation>,
        retrofit: Retrofit
    ): CallAdapter<*, *>? {
        if (Call::class.java != getRawType(returnType)) {
            return null
        }
        check(returnType is ParameterizedType) {
            "return type must be parameterized as Call<HttpResult<<Foo>> or Call<HttpResult<out Foo>>"
        }
        // 获取`Call` type
        val responseType = getParameterUpperBound(0, returnType)

        // 类型检查
        if (getRawType(responseType) != HttpResult::class.java) {
            return null
        }

        check(responseType is ParameterizedType) { "Response must be parameterized as HttpResult<Foo> or HttpResponse<out Foo>" }

        // 上面都是一些基本的参数检查，类型匹配
        return object : CallAdapter<Any, Call<*>?> {
            override fun responseType(): Type {
                return responseType
            }

            override fun adapt(call: Call<Any>): Call<*> {
                // 为了返回HttpResult<T>
                return HttpResponseCall(call, errorHandler)
            }

        }

    }
}