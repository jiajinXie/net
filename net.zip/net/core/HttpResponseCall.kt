package com.iflytek.easytrans.crossdevice.translation.net.core

import com.iflytek.easytrans.crossdevice.translation.net.error.BusinessException
import okhttp3.Request
import okio.Timeout
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/**
 * @author jjxie9
 * @date 2024/9/23
 * @description
 */
internal class HttpResponseCall<S : Any>(
    private val call: Call<S>,
    private val errorConverter: HttpResponseCallAdapterFactory.ErrorHandler?
) : Call<HttpResult<S>> {


    override fun enqueue(callback: Callback<HttpResult<S>>) {
        return call.enqueue(object : Callback<S> {
            override fun onResponse(call: Call<S>, response: Response<S>) {
                val data = response.body()
                val code = response.code()
                val message = response.message().ifEmpty { "Unknown error" }
                if (response.isSuccessful) {
                    val result = if (data != null) {
                        HttpResult.Success(data)
                    } else {
                        HttpResult.Failure("Response body is null", -1)
                    }
                    callback.onResponse(this@HttpResponseCall, Response.success(result))
                } else {
                    errorConverter?.onFailure(BusinessException(code, message))
                    val failureResult =
                        HttpResult.Failure(message, code)
                    callback.onResponse(this@HttpResponseCall, Response.success(failureResult))
                }
            }

            override fun onFailure(call: Call<S>, throwable: Throwable) {
                val networkResponse = when (throwable) {
                    is SocketTimeoutException -> HttpResult.Failure(
                        "Network timeout. Please try again.",
                        -1
                    )
                    is ConnectException -> HttpResult.Failure(
                        "Failed to connect to the server.",
                        -1
                    )

                    is UnknownHostException -> HttpResult.Failure("No internet connection.", -1)
                    is IOException -> HttpResult.Failure(
                        throwable.message ?: "Network error occurred.", -1
                    )
                    // 自定义业务异常
                    is BusinessException -> {
                        errorConverter?.onFailure(throwable)
                        HttpResult.Failure(throwable.message ?: "Business error", throwable.code)
                    }

                    else -> HttpResult.Failure(throwable.message ?: "Unknown error occurred.", -2)
                }
                callback.onResponse(
                    this@HttpResponseCall,
                    Response.success(networkResponse)
                )
            }
        })
    }

    override fun execute(): Response<HttpResult<S>> {
        return try {
            val response = call.execute()
            val data = response.body()
            val code = response.code()
            val message = response.message().ifEmpty { "Unknown error" } // 确保 message 不为空
            if (response.isSuccessful) {
                return if (data != null) {
                    Response.success(HttpResult.Success(data))
                } else {
                    Response.success(HttpResult.Failure("Response body is null", -1))
                }
            }
            // 处理失败响应
            errorConverter?.onFailure(BusinessException(code, message))
            Response.success(HttpResult.Failure(message, code))
        } catch (e: Exception) {
            Response.success(
                HttpResult.Failure(
                    "Network request failed: ${e.message ?: "Unknown error"}", -2
                )
            )
        }
    }

    override fun isExecuted() = call.isExecuted

    override fun clone() = HttpResponseCall(call.clone(), errorConverter)

    override fun isCanceled() = call.isCanceled

    override fun cancel() = call.cancel()

    override fun request(): Request = call.request()

    override fun timeout(): Timeout = call.timeout()


}
