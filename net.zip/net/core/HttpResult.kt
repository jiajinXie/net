package com.iflytek.easytrans.crossdevice.translation.net.core


/**
 * @author jjxie9
 * @date 2024/9/23
 * @description 请求返回的数据结果
 */
sealed class HttpResult<out T> {
    data class Success<out T>(val data: T?) : HttpResult<T>()
    data class Failure(val message: String, val code: Int? = null) : HttpResult<Nothing>()
}



