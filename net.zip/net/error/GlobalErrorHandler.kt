package com.iflytek.easytrans.crossdevice.translation.net.error

import com.iflytek.easytrans.crossdevice.translation.net.core.HttpResponseCallAdapterFactory

/**
 * @author jjxie9
 * @date 2024/9/23
 * @description 全局错误码处理
 */
class GlobalErrorHandler : HttpResponseCallAdapterFactory.ErrorHandler {
    override fun onFailure(throwable: BusinessException) {
        when (throwable.code) {
            101 -> {

            }

            102 -> {

            }
        }
    }
}