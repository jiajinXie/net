package com.iflytek.easytrans.crossdevice.translation.net.interceptor

import android.util.Log
import com.iflytek.easytrans.core.utils.log.LogUtils
import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException

/**
 * @author jjxie9
 * @date 2024/9/23
 * @description 响应拦截器
 */
class CommonResponseInterceptor : Interceptor {
    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {
        val requestTime = System.currentTimeMillis()

        val response: Response = chain.proceed(chain.request())

        //Token 过期，解密，通用错误拦截等等
        LogUtils.d(TAG, "requestTime=" + (System.currentTimeMillis() - requestTime))

        return response
    }

    companion object {
        private const val TAG = "ResponseInterceptor"
    }
}