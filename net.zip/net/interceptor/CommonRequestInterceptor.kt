package com.iflytek.easytrans.crossdevice.translation.net.interceptor

import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response
import java.io.IOException

/**
 * @author jjxie9
 * @date 2024/9/23
 * @description 通用的请求拦截器
 */
class CommonRequestInterceptor : Interceptor {
    /**
     * 怎么设置拦截器
     *
     * @param chain
     * @return
     * @throws IOException
     */
    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {
        val builder: Request.Builder = chain.request().newBuilder()

        builder.addHeader("Accept", "application/json")


        /*builder.addHeader("X-Version", "Version");
        builder.addHeader("X-Platform", "Android");
        builder.addHeader("Connection", "Keep-Alive");
        builder.addHeader("User-Agent", "yourAppLabel-Android");
*/
        return chain.proceed(builder.build())
    }
}